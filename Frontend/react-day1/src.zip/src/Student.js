function Student(props) {
    return (<div>
        <p>Student Name: <b>{props.name}, {props.age}</b></p>
        </div>)
}
export default Student;