function Trainer(props){
    return(
<div>
    <p>Trainer :{props.name}, {props.topic}</p>
</div>
    )
}
export default Trainer;