import UserForm from "./UserForm";

function Main(){
    return(
        <div>
            <UserForm/>
        </div>
    )
}
export default Main;