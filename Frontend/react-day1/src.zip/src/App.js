function App(){
  return (
    <div>
    <h1>Welcome to react JS</h1>
    </div>
  )
  }
  export default App;